store = input('Input your favorite show: ')
print(f"You are now watching {store}")