# This is absolutely an infinite loop
store = input("There is a chair here. Sit in it? ")
if store[0].lower() == "y":
    print("This is a comfortable chair you don't want to leave.")
    while True:
        input("Leave the chair? ")
        print("You don't want to leave the chair.")
else:
    print("lame.")